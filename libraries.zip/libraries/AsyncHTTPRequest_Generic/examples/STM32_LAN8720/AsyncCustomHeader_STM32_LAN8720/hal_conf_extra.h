// Note: Must replace 
// .arduino15/packages/STM32/hardware/stm32/1.9.0/system/STM32F4xx/stm32f4xx_hal_conf_default.h
// as described in README.md

#define HAL_ETH_MODULE_ENABLED

#define LAN8742A_PHY_ADDRESS            0x01U
